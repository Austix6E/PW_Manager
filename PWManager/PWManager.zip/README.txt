Project: PWManager
Engineer: Austin Cole
Email: austi01101110@gmail.com

********************************************************************************

Dimensions:
X = 35.25
Y = 64.75

Layer Count = 2
Thickness = 0.062"
Copper Wt. = 1 oz
Silkscreen: Top Side

Files:

.GBL    Bottom Copper
.GBS    Bottom Soldermask
.GTL    Top Copper
.GTO    Top Silkscreen
.GTS    Top Soldermask
.GM1	Board Outline
.DRL    Binary Drill File
.GTP	Top Paste - for stencil